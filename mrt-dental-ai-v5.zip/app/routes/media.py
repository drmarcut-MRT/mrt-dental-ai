from flask import Blueprint, request, jsonify, current_app, send_from_directory
from datetime import datetime
import secrets
from app.services.media import generate_image, submit_video, upsert, records, find_record
bp=Blueprint("media",__name__)

@bp.post("/api/media/generate")
def generate():
    kind=request.form.get("kind","image")
    prompt=request.form.get("prompt","").strip()
    if not prompt: return jsonify(error="Descriere lipsă"),400
    try:
        if kind=="image":
            fn=generate_image(prompt)
            rec={"id":secrets.token_hex(8),"kind":"image","prompt":prompt,"filename":fn,"status":"ready",
                 "saved":False,"created_at":datetime.now().isoformat()}
        else:
            d=submit_video(prompt,request.form.get("aspect_ratio","9:16"),request.form.get("duration","5"),
                           request.form.get("resolution","720p"),request.form.get("generate_audio")=="1")
            rec={"id":secrets.token_hex(8),"kind":"video","prompt":prompt,"status":"pending","saved":False,
                 "request_id":d.get("request_id"),"status_url":d.get("status_url"),"response_url":d.get("response_url"),
                 "cancel_url":d.get("cancel_url"),"created_at":datetime.now().isoformat()}
        upsert(rec); return jsonify(rec),201
    except Exception as e: return jsonify(error=str(e)),502

@bp.get("/api/library")
def library(): return jsonify([x for x in records() if x.get("status")=="ready"])

@bp.delete("/api/media/<rid>")
def delete(rid):
    rows=records(); rec=next((x for x in rows if str(x.get("id"))==rid),None)
    if not rec: return "",404
    from pathlib import Path
    if rec.get("filename"):
        try: (Path(current_app.config["MEDIA_DIR"])/rec["filename"]).unlink()
        except FileNotFoundError: pass
    from app.services.media import save_records
    save_records([x for x in rows if str(x.get("id"))!=rid])
    return "",204

@bp.get("/uploads/<path:name>")
def upload(name): return send_from_directory(current_app.config["MEDIA_DIR"],name)
