from pathlib import Path
from datetime import datetime
import base64, json, os, secrets, urllib.request, urllib.error
from flask import current_app
from .storage import load_json, save_json

def records_file(): return Path(current_app.config["DATA_DIR"])/"generated_media.json"
def records(): 
    x=load_json(records_file(),[])
    return x if isinstance(x,list) else []
def save_records(rows): save_json(records_file(),rows)
def find_record(rid): return next((x for x in records() if str(x.get("id"))==str(rid)),None)
def upsert(rec):
    rows=records()
    for i,x in enumerate(rows):
        if str(x.get("id"))==str(rec.get("id")): rows[i]=rec; break
    else: rows.append(rec)
    save_records(rows)

def generate_image(prompt):
    key=current_app.config["OPENAI_API_KEY"]
    if not key: raise RuntimeError("Cheia OpenAI API nu este configurată.")
    payload=json.dumps({"model":"gpt-image-2","prompt":prompt,"size":"1024x1024"}).encode()
    req=urllib.request.Request("https://api.openai.com/v1/images/generations",data=payload,method="POST",
        headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=180) as resp: data=json.loads(resp.read())
    item=(data.get("data") or [{}])[0]
    raw=base64.b64decode(item["b64_json"]) if item.get("b64_json") else urllib.request.urlopen(item["url"],timeout=120).read()
    media=Path(current_app.config["MEDIA_DIR"]); media.mkdir(parents=True,exist_ok=True)
    name=datetime.now().strftime("generated_%Y%m%d_%H%M%S_")+secrets.token_hex(4)+".png"
    (media/name).write_bytes(raw); return name

def submit_video(prompt, aspect_ratio, duration, resolution, generate_audio):
    key=current_app.config["FAL_KEY"]
    if not key: raise RuntimeError("Pentru generare video mai trebuie configurată cheia FAL_KEY.")
    endpoint="bytedance/seedance-2.5/us/text-to-video"
    payload=json.dumps({"prompt":prompt,"aspect_ratio":aspect_ratio,"duration":duration,
                        "resolution":resolution,"generate_audio":bool(generate_audio)}).encode()
    req=urllib.request.Request("https://queue.fal.run/"+endpoint,data=payload,method="POST",
        headers={"Authorization":"Key "+key,"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=30) as resp: return json.loads(resp.read())
