# MRT Dental AI v4 — working copy

Copie de dezvoltare separată de aplicația live din Railway.

## Ce include
- Content Studio: briefuri persistente în fișiere JSON
- Propuneri AI: generare, editare, revizuire și aprobare
- Aprobare -> Bibliotecă de conținut persistentă
- Media: generare imagine/video și bibliotecă media
- Dictare/transcriere RO
- configurare exclusiv prin variabile de mediu pentru cheile API
- scrieri JSON atomice pentru reducerea riscului de fișiere parțial scrise

## Configurare
Copiază `.env.example` în mediul de rulare și setează cheile ca variabile de mediu. Nu comite cheile API în Git.

## Pornire
`pip install -r requirements.txt`
`python run.py`

## Testare
`pytest -q`

Testele includ validarea briefurilor, protecția la salvarea unei propuneri inexistente și fluxul aprobare -> bibliotecă.

## Notă
Această arhivă nu modifică și nu face deploy în Railway.

## v5 hardening
- `/health` raportează versiunea, ora UTC și dacă integrarea AI/media este configurată, fără a expune chei.
- Răspunsuri JSON coerente pentru 404/405/500.
- Test de integrare pentru fluxul complet brief → generare → editare → aprobare → bibliotecă, cu AI mock-uit (fără apel extern).
