
import os, json, base64, urllib.request, urllib.error, secrets, time
from datetime import datetime
from flask import request, redirect

_MRT_MEDIA_PATCH_V3_LOADED = True
_MRT_BASE = globals().get("BASE", "/tmp/mrt_dental_ai")
_MRT_MEDIA = globals().get("MEDIA", os.path.join(_MRT_BASE, "media"))
_MRT_GEN_FILE = os.path.join(_MRT_BASE, "generated_media.json")
_MRT_NOTES_FILE = os.path.join(_MRT_BASE, "media_notes.json")
os.makedirs(_MRT_MEDIA, exist_ok=True)

def _mrt_json_load(path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return fallback

def _mrt_json_save(path, value):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def _mrt_records():
    x = _mrt_json_load(_MRT_GEN_FILE, [])
    return x if isinstance(x, list) else []

def _mrt_save_records(rows):
    _mrt_json_save(_MRT_GEN_FILE, rows)

def _mrt_find(rid):
    for x in _mrt_records():
        if str(x.get("id","")) == str(rid):
            return x
    return None

def _mrt_upsert(rec):
    rows = _mrt_records()
    found = False
    for i,x in enumerate(rows):
        if str(x.get("id","")) == str(rec.get("id","")):
            rows[i] = rec
            found = True
            break
    if not found:
        rows.append(rec)
    _mrt_save_records(rows)

def _mrt_html_escape(v):
    try:
        return esc(v)
    except Exception:
        import html
        return html.escape(str(v or ""), quote=True)

def _mrt_openai_image(prompt):
    key = os.getenv("OPENAI_API_KEY","").strip()
    if not key:
        raise RuntimeError("Cheia OpenAI API nu este configurată.")
    payload = json.dumps({
        "model": "gpt-image-2",
        "prompt": prompt,
        "size": "1024x1024"
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/images/generations",
        data=payload,
        method="POST",
        headers={
            "Authorization": "Bearer " + key,
            "Content-Type": "application/json"
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            data = json.loads(resp.read().decode("utf-8","replace"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8","replace")
        try:
            j = json.loads(detail)
            msg = ((j.get("error") or {}).get("message") or detail)
        except Exception:
            msg = detail
        raise RuntimeError("OpenAI: " + str(msg)[:900])
    arr = data.get("data") if isinstance(data, dict) else None
    if not isinstance(arr, list) or not arr:
        raise RuntimeError("OpenAI nu a returnat o imagine.")
    item = arr[0] if isinstance(arr[0], dict) else {}
    raw = None
    if item.get("b64_json"):
        raw = base64.b64decode(item["b64_json"])
    elif item.get("url"):
        with urllib.request.urlopen(item["url"], timeout=120) as imgresp:
            raw = imgresp.read()
    if not raw:
        raise RuntimeError("Imaginea a fost generată, dar fișierul nu a putut fi citit.")
    filename = datetime.now().strftime("generated_%Y%m%d_%H%M%S_") + secrets.token_hex(4) + ".png"
    with open(os.path.join(_MRT_MEDIA, filename), "wb") as f:
        f.write(raw)
    return filename

def _mrt_fal_submit(prompt, aspect_ratio, duration, resolution, generate_audio):
    key = os.getenv("FAL_KEY","").strip()
    if not key:
        raise RuntimeError("Pentru generare video mai trebuie configurată cheia FAL_KEY.")
    endpoint = "bytedance/seedance-2.5/us/text-to-video"
    payload = json.dumps({
        "prompt": prompt,
        "aspect_ratio": aspect_ratio,
        "duration": duration,
        "resolution": resolution,
        "generate_audio": bool(generate_audio)
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://queue.fal.run/" + endpoint,
        data=payload,
        method="POST",
        headers={
            "Authorization": "Key " + key,
            "Content-Type": "application/json"
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8","replace"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8","replace")
        raise RuntimeError("fal.ai: " + detail[:900])
    if not data.get("request_id"):
        raise RuntimeError("fal.ai nu a returnat un request_id.")
    return data

def _mrt_fal_refresh(rec):
    if rec.get("kind") != "video" or rec.get("status") not in ("pending","processing"):
        return rec
    key = os.getenv("FAL_KEY","").strip()
    if not key:
        return rec
    status_url = rec.get("status_url")
    response_url = rec.get("response_url")
    if not status_url:
        return rec
    headers = {"Authorization": "Key " + key}
    try:
        req = urllib.request.Request(status_url, headers=headers)
        with urllib.request.urlopen(req, timeout=20) as resp:
            st = json.loads(resp.read().decode("utf-8","replace"))
        q = str(st.get("status","")).upper()
        if q == "COMPLETED":
            if response_url:
                req2 = urllib.request.Request(response_url, headers=headers)
                with urllib.request.urlopen(req2, timeout=30) as resp2:
                    result = json.loads(resp2.read().decode("utf-8","replace"))
                video = result.get("video") if isinstance(result, dict) else None
                url = video.get("url") if isinstance(video, dict) else None
                if url:
                    filename = datetime.now().strftime("generated_%Y%m%d_%H%M%S_") + secrets.token_hex(4) + ".mp4"
                    with urllib.request.urlopen(url, timeout=180) as vresp:
                        raw = vresp.read()
                    with open(os.path.join(_MRT_MEDIA, filename), "wb") as f:
                        f.write(raw)
                    rec["filename"] = filename
                    rec["status"] = "ready"
                    rec["updated_at"] = datetime.now().isoformat()
        elif q in ("IN_QUEUE","IN_PROGRESS"):
            rec["status"] = "processing" if q == "IN_PROGRESS" else "pending"
        return rec
    except Exception as e:
        rec["last_error"] = str(e)[:500]
        return rec

def _mrt_save_to_library(rec):
    if not rec or not rec.get("filename"):
        return False
    notes = _mrt_json_load(_MRT_NOTES_FILE, [])
    if not isinstance(notes, list):
        notes = []
    if any(str(x.get("generated_id","")) == str(rec.get("id","")) for x in notes if isinstance(x,dict)):
        return True
    notes.append({
        "generated_id": rec.get("id"),
        "stored_name": rec.get("filename"),
        "original_name": rec.get("filename"),
        "content_type": "image/png" if rec.get("kind") == "image" else "video/mp4",
        "note": rec.get("prompt",""),
        "created_at": datetime.now().strftime("%d.%m.%Y %H:%M")
    })
    _mrt_json_save(_MRT_NOTES_FILE, notes)
    rec["saved"] = True
    _mrt_upsert(rec)
    return True

def _mrt_generate_view():
    error = ""
    rid = request.args.get("rid","").strip()
    rec = _mrt_find(rid) if rid else None

    if request.method == "POST":
        kind = request.form.get("kind","image").strip()
        prompt = request.form.get("prompt","").strip()
        client_job_id = request.form.get("client_job_id","").strip()
        if not prompt:
            error = "Scrie sau dictează descrierea înainte de generare."
        elif kind == "image":
            try:
                filename = _mrt_openai_image(prompt)
                if client_job_id and client_job_id in _MRT_CANCELLED_JOBS:
                    try: os.remove(os.path.join(_MRT_MEDIA, os.path.basename(filename)))
                    except Exception: pass
                    return ("", 204)
                rec = {
                    "id": secrets.token_hex(8),
                    "kind": "image",
                    "prompt": prompt,
                    "filename": filename,
                    "status": "ready",
                    "saved": False,
                    "created_at": datetime.now().isoformat()
                }
                _mrt_upsert(rec)
                return redirect("/generate?rid=" + rec["id"])
            except Exception as e:
                error = str(e)
        elif kind == "video":
            try:
                aspect_ratio = request.form.get("aspect_ratio","9:16")
                duration = request.form.get("duration","5")
                resolution = request.form.get("resolution","720p")
                generate_audio = request.form.get("generate_audio") == "1"
                data = _mrt_fal_submit(prompt, aspect_ratio, duration, resolution, generate_audio)
                rec = {
                    "id": secrets.token_hex(8),
                    "kind": "video",
                    "prompt": prompt,
                    "status": "pending",
                    "saved": False,
                    "request_id": data.get("request_id"),
                    "status_url": data.get("status_url"),
                    "response_url": data.get("response_url"),
                    "cancel_url": data.get("cancel_url"),
                    "created_at": datetime.now().isoformat()
                }
                _mrt_upsert(rec)
                return redirect("/generate?rid=" + rec["id"])
            except Exception as e:
                error = str(e)

    if rec and rec.get("kind") == "video" and rec.get("status") in ("pending","processing"):
        rec = _mrt_fal_refresh(rec)
        _mrt_upsert(rec)

    selected_kind = (rec or {}).get("kind","image")
    prompt_value = (rec or {}).get("prompt","")
    fal_ready = bool(os.getenv("FAL_KEY","").strip())

    result_html = ""
    if rec:
        if rec.get("status") == "ready" and rec.get("filename"):
            src = "/uploads/" + urllib.parse.quote(rec.get("filename",""))
            if rec.get("kind") == "image":
                media = f'<img src="{src}" alt="Imagine generată" style="width:100%;max-width:720px;border-radius:16px;border:1px solid #e5e7eb;display:block;margin:0 auto">'
            else:
                media = f'<video src="{src}" controls playsinline style="width:100%;max-width:720px;border-radius:16px;border:1px solid #e5e7eb;display:block;margin:0 auto"></video>'
            saved = bool(rec.get("saved"))
            save_btn = '<p style="color:#047857;font-weight:700">✓ Salvat în bibliotecă</p>' if saved else (
                '<form method="post" action="/generated/save"><input type="hidden" name="rid" value="'+_mrt_html_escape(rec.get("id"))+'">'
                '<button class="btnx primaryx" type="submit">✓ Salvează în bibliotecă</button></form>'
            )
            result_html = '<section class="panelx"><h2>Rezultat generat</h2>'+media+'<div style="margin-top:16px">'+save_btn+'</div></section>'
        elif rec.get("kind") == "video":
            status_text = "În coadă..." if rec.get("status") == "pending" else "Se generează..."
            result_html = (
                '<section class="panelx"><h2>Video în curs</h2><p>'+status_text+'</p>'
                '<a class="btnx secondaryx" href="/generate?rid='+_mrt_html_escape(rec.get("id"))+'">Verifică statusul</a></section>'
            )

    err_html = ('<div class="cardx" style="border-color:#fecaca;background:#fff7f7;color:#991b1b"><strong>'+_mrt_html_escape(error)+'</strong></div>') if error else ""
    fal_note = "" if fal_ready else '<p class="mutedx" id="video-note">Generarea video este pregătită în interfață, dar pentru a porni efectiv mai trebuie configurată cheia FAL_KEY.</p>'

    content = f'''
<section class="panelx">
  <h2>Generează imagine sau video</h2>
  <p class="mutedx">Descrii ce vrei, prin voce sau text, iar aplicația generează media propriu-zisă — nu un răspuns textual.</p>
  {err_html}
  <form method="post" id="mrt-media-form">
    <label>Ce vrei să generezi?</label>
    <div class="rowx" style="margin-bottom:12px">
      <label style="display:inline-flex;gap:7px;align-items:center;margin:0"><input style="width:auto" type="radio" name="kind" value="image" {"checked" if selected_kind=="image" else ""}> Imagine</label>
      <label style="display:inline-flex;gap:7px;align-items:center;margin:0"><input style="width:auto" type="radio" name="kind" value="video" {"checked" if selected_kind=="video" else ""}> Video</label>
    </div>

    <label>Descriere</label>
    <textarea id="mrt-prompt" data-mrt-voice="1" name="prompt" rows="8" placeholder="Ex.: Generează un incisiv central superior cu anatomie realistă, parodonțiu și os alveolar...">{_mrt_html_escape(prompt_value)}</textarea>
    <div class="rowx" style="margin:8px 0 14px">
      <button class="btnx secondaryx" id="mrt-dictate" type="button">🎙 Dictează</button>
      <span id="mrt-dictate-status" class="mutedx">română</span>
    </div>

    <div id="mrt-video-options" style="display:none">
      <div class="formgrid">
        <label>Format
          <select name="aspect_ratio">
            <option value="9:16">9:16 vertical</option>
            <option value="1:1">1:1 pătrat</option>
            <option value="16:9">16:9 landscape</option>
          </select>
        </label>
        <label>Durată
          <select name="duration">
            <option value="5">5 secunde</option>
            <option value="8">8 secunde</option>
            <option value="10">10 secunde</option>
          </select>
        </label>
        <label>Rezoluție
          <select name="resolution">
            <option value="720p">720p</option>
            <option value="1080p">1080p</option>
            <option value="480p">480p</option>
          </select>
        </label>
      </div>
      <label style="display:flex;gap:8px;align-items:center"><input style="width:auto" type="checkbox" name="generate_audio" value="1"> Generează și sunet</label>
      {fal_note}
    </div>

    <input type="hidden" name="client_job_id" id="mrt-client-job-id" value="">
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
<button class="btnx primaryx" id="mrt-generate-btn" type="submit">✨ Generează</button>
<button class="btnx secondaryx" id="mrt-stop-btn" type="button" style="display:none">■ Stop</button>
</div><p id="mrt-generation-status" class="mutedx"></p>
  </form>
</section>
{result_html}

<script>
(function(){{
  const form=document.getElementById('mrt-media-form');
  const videoBox=document.getElementById('mrt-video-options');
  function syncKind(){{
    const k=(form.querySelector('input[name="kind"]:checked')||{{value:'image'}}).value;
    videoBox.style.display=k==='video'?'block':'none';
  }}
  form.querySelectorAll('input[name="kind"]').forEach(x=>x.addEventListener('change',syncKind));
  syncKind();

  const ta=document.getElementById('mrt-prompt');
  const btn=document.getElementById('mrt-dictate');
  const status=document.getElementById('mrt-dictate-status');
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){{
    btn.disabled=true;
    status.textContent='dictare indisponibilă în acest browser';
    return;
  }}
  let rec=null, active=false, base='';
  btn.addEventListener('click',function(){{
    if(active){{ try{{rec.stop()}}catch(e){{}} return; }}
    rec=new SR();
    rec.lang='ro-RO';
    rec.continuous=true;
    rec.interimResults=true;
    base=(ta.value||'').trim();
    if(base) base += ' ';
    rec.onstart=()=>{{active=true;btn.textContent='■ Oprește';status.textContent='ascult…';}};
    rec.onresult=(ev)=>{{
      let finals='', interim='';
      for(let i=ev.resultIndex;i<ev.results.length;i++){{
        const t=(ev.results[i][0].transcript||'').trim();
        if(!t) continue;
        if(ev.results[i].isFinal) finals += (finals?' ':'') + t;
        else interim += (interim?' ':'') + t;
      }}
      ta.value=(base + finals + (interim ? (finals?' ':'')+interim : '')).trim();
      ta.dispatchEvent(new Event('input',{{bubbles:true}}));
    }};
    rec.onerror=(ev)=>{{status.textContent=ev.error==='not-allowed'?'permite accesul la microfon':'eroare microfon';}};
    rec.onend=()=>{{active=false;btn.textContent='🎙 Dictează';if(status.textContent==='ascult…') status.textContent='română';}};
    try{{rec.start()}}catch(e){{status.textContent='încearcă din nou';}}
  }});
}})();

;(function(){{
  function installMrtSpeechV2(){{
    const oldBtn=document.getElementById('mrt-dictate');
    const ta=document.getElementById('mrt-prompt');
    const status=document.getElementById('mrt-dictate-status');
    if(!oldBtn||!ta||!status) return;
    if(oldBtn.dataset && oldBtn.dataset.mrtSpeechV2==='1') return;

    // Replace the node to remove every older/global click listener.
    const btn=oldBtn.cloneNode(true);
    btn.removeAttribute('data-mrt-voice');
    btn.dataset.mrtSpeechV2='1';
    oldBtn.replaceWith(btn);

    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){{
      btn.disabled=true;
      status.textContent='dictare indisponibilă în acest browser';
      return;
    }}

    let rec=null, active=false, prefix='', committed='';

    const clean=(s)=>(s||'').trim().replace(/\s+/g,' ');

    function mergeOverlap(a,b){{
      a=clean(a); b=clean(b);
      if(!a) return b;
      if(!b) return a;
      const al=a.toLocaleLowerCase('ro-RO');
      const bl=b.toLocaleLowerCase('ro-RO');
      if(al===bl) return a;
      if(bl.startsWith(al+' ')) return b;
      if(al.endsWith(' '+bl) || al===bl) return a;

      const aw=a.split(' '), bw=b.split(' ');
      const an=aw.map(x=>x.toLocaleLowerCase('ro-RO'));
      const bn=bw.map(x=>x.toLocaleLowerCase('ro-RO'));
      const max=Math.min(an.length,bn.length);
      for(let k=max;k>0;k--){{
        let ok=true;
        for(let j=0;j<k;j++){{
          if(an[an.length-k+j]!==bn[j]){{ok=false;break;}}
        }}
        if(ok) return aw.concat(bw.slice(k)).join(' ');
      }}
      return a+' '+b;
    }}

    function render(interim){{
      const spoken=mergeOverlap(committed,interim||'');
      ta.value=clean((prefix?prefix+' ':'')+spoken);
      ta.dispatchEvent(new Event('input',{{bubbles:true}}));
    }}

    btn.addEventListener('click',function(ev){{
      ev.preventDefault();
      ev.stopImmediatePropagation();

      if(active){{
        try{{rec.stop();}}catch(e){{}}
        return;
      }}

      prefix=clean(ta.value);
      committed='';
      rec=new SR();
      rec.lang='ro-RO';
      rec.continuous=true;
      rec.interimResults=true;

      rec.onstart=()=>{{
        active=true;
        btn.textContent='■ Oprește';
        status.textContent='ascult…';
      }};

      rec.onresult=(ev)=>{{
        let interim='';
        for(let i=ev.resultIndex;i<ev.results.length;i++){{
          const alt=ev.results[i] && ev.results[i][0];
          const t=clean(alt && alt.transcript);
          if(!t) continue;
          if(ev.results[i].isFinal){{
            committed=mergeOverlap(committed,t);
          }}else{{
            interim=t;
          }}
        }}
        render(interim);
      }};

      rec.onerror=(ev)=>{{
        status.textContent=ev.error==='not-allowed'?'permite accesul la microfon':'eroare microfon';
      }};

      rec.onend=()=>{{
        active=false;
        btn.textContent='🎙 Dictează';
        if(status.textContent==='ascult…') status.textContent='română';
        rec=null;
      }};

      try{{rec.start();}}catch(e){{status.textContent='încearcă din nou';}}
    }},true);
  }}

  const boot=()=>setTimeout(installMrtSpeechV2,120);
  if(document.readyState==='loading'){{
    document.addEventListener('DOMContentLoaded',boot,{{once:true}});
  }}else{{
    boot();
  }}
}})();

;(function(){{
 const f=document.getElementById('mrt-media-form'); if(!f||f.dataset.stopV5==='1')return; f.dataset.stopV5='1';
 const g=document.getElementById('mrt-generate-btn'),s=document.getElementById('mrt-stop-btn'),st=document.getElementById('mrt-generation-status'),jf=document.getElementById('mrt-client-job-id');
 if(g&&s&&jf){{
   let ctl=null,busy=false;
   const jid=()=>window.crypto&&crypto.randomUUID?crypto.randomUUID():'job-'+Date.now()+'-'+Math.random().toString(16).slice(2);
   f.addEventListener('submit',async e=>{{e.preventDefault();e.stopImmediatePropagation();if(busy)return;busy=true;ctl=new AbortController();jf.value=jid();g.disabled=true;s.style.display='inline-flex';if(st)st.textContent='Se generează…';
   try{{const r=await fetch('/generate',{{method:'POST',body:new FormData(f),credentials:'same-origin',signal:ctl.signal}});if(ctl.signal.aborted)return;if(r.status===204){{if(st)st.textContent='Generare oprită.';return;}}if(r.redirected){{location.href=r.url;return;}}const h=await r.text();document.open();document.write(h);document.close();}}
   catch(err){{if(st)st.textContent=err&&err.name==='AbortError'?'Generare oprită.':'Eroare la generare.';}}
   finally{{busy=false;g.disabled=false;s.style.display='none';ctl=null;}}}},true);
   s.addEventListener('click',()=>{{const id=jf.value;if(ctl)ctl.abort();const fd=new FormData();fd.append('job_id',id);fetch('/generated/stop-client',{{method:'POST',body:fd,credentials:'same-origin',keepalive:true}}).catch(()=>{{}});busy=false;g.disabled=false;s.style.display='none';if(st)st.textContent='Generare oprită.';}});
 }}
 const rid=new URLSearchParams(location.search).get('rid');
 if(rid){{
   const panels=[...document.querySelectorAll('.panelx')];
   const target=panels.find(x=>/Rezultat generat|Video în curs|Generare oprită/i.test(x.textContent||''));
   if(target&&!target.dataset.controlsV5){{
     target.dataset.controlsV5='1';
     const row=document.createElement('div');row.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin-top:12px';
     if(/Video în curs/i.test(target.textContent||'')){{
       const sf=document.createElement('form');sf.method='post';sf.action='/generated/cancel';sf.innerHTML='<input type="hidden" name="rid" value="'+rid+'"><button class="btnx secondaryx" type="submit">■ Stop</button>';row.appendChild(sf);
     }}
     const df=document.createElement('form');df.method='post';df.action='/generated/delete';df.onsubmit=()=>confirm('Ștergi definitiv acest element?');df.innerHTML='<input type="hidden" name="rid" value="'+rid+'"><input type="hidden" name="return_to" value="/generate"><button class="btnx secondaryx" type="submit">🗑 Șterge</button>';row.appendChild(df);
     target.appendChild(row);
   }}
 }}
}})();
</script>
'''
    return layout("Generează conținut", content)

def _mrt_generated_save():
    rid = request.form.get("rid","").strip()
    rec = _mrt_find(rid)
    if rec:
        _mrt_save_to_library(rec)
    return redirect("/generate?rid=" + urllib.parse.quote(rid))

app.view_functions["generate"] = _mrt_generate_view
if "mrt_generated_save" not in app.view_functions:
    app.add_url_rule("/generated/save", endpoint="mrt_generated_save", view_func=_mrt_generated_save, methods=["POST"])

print("MRT_MEDIA_PATCH_V3=loaded", flush=True)


from flask import jsonify as _mrt_jsonify
import urllib.request as _mrt_req, urllib.parse as _mrt_parse
_MRT_CANCELLED_JOBS=set()
def _mrt_cancel_fal_v5(rec):
    if not rec or rec.get("kind")!="video": return False
    key=os.getenv("FAL_KEY","").strip(); q=str(rec.get("request_id") or "")
    if not key or not q:return False
    u=str(rec.get("cancel_url") or "") or ("https://queue.fal.run/bytedance/seedance-2.5/us/text-to-video/requests/"+_mrt_parse.quote(q)+"/cancel")
    try:
        r=_mrt_req.Request(u,data=b"",method="PUT",headers={"Authorization":"Key "+key})
        with _mrt_req.urlopen(r,timeout=20) as x:x.read()
        return True
    except Exception:return False
def _mrt_stop_client_v5():
    j=str(request.form.get("job_id","") or "")
    if j:_MRT_CANCELLED_JOBS.add(j)
    return _mrt_jsonify({"ok":True})
def _mrt_cancel_v5():
    rid=str(request.form.get("rid","") or ""); rec=_mrt_find(rid)
    if rec:_mrt_cancel_fal_v5(rec);rec["status"]="cancelled";_mrt_upsert(rec)
    return redirect("/generate?rid="+_mrt_parse.quote(rid))
def _mrt_delete_v5():
    rid=str(request.form.get("rid","") or ""); ret=str(request.form.get("return_to","/library") or "/library")
    if not ret.startswith("/"):ret="/library"
    rows=_mrt_records();keep=[];deleted_files=[]
    for x in rows:
        if isinstance(x,dict) and str(x.get("id",""))==rid:
            if x.get("status") in ("pending","processing"):_mrt_cancel_fal_v5(x)
            fn=os.path.basename(str(x.get("filename","") or ""))
            if fn:deleted_files.append(fn)
        else:keep.append(x)
    _mrt_save_records(keep)
    notes=_mrt_json_load(_MRT_NOTES_FILE,[]); notes=notes if isinstance(notes,list) else []
    _mrt_json_save(_MRT_NOTES_FILE,[n for n in notes if not(isinstance(n,dict) and str(n.get("generated_id",""))==rid)])
    for fn in deleted_files:
        try:os.remove(os.path.join(_MRT_MEDIA,fn))
        except Exception:pass
    return redirect(ret)
if "mrt_stop_client_v5" not in app.view_functions:app.add_url_rule("/generated/stop-client",endpoint="mrt_stop_client_v5",view_func=_mrt_stop_client_v5,methods=["POST"])
if "mrt_cancel_v5" not in app.view_functions:app.add_url_rule("/generated/cancel",endpoint="mrt_cancel_v5",view_func=_mrt_cancel_v5,methods=["POST"])
if "mrt_delete_v5" not in app.view_functions:app.add_url_rule("/generated/delete",endpoint="mrt_delete_v5",view_func=_mrt_delete_v5,methods=["POST"])
print("MRT_STOP_DELETE_V5=loaded",flush=True)



_MRT_BRIEFS_V5=os.path.join(_MRT_BASE,'briefs.json')
def _mrt_delete_brief_v5():
    bid=str(request.form.get('brief_id','') or '')
    data=_mrt_json_load(_MRT_BRIEFS_V5,[])
    if not isinstance(data,list): data=[]
    out=[]
    for i,x in enumerate(data):
        if isinstance(x,dict) and (str(x.get('id',''))==bid or (bid.isdigit() and int(bid)==i)):
            continue
        out.append(x)
    _mrt_json_save(_MRT_BRIEFS_V5,out)
    return redirect('/library')

def _mrt_lib_card_v5(x):
    rid=str(x.get('id',''))
    kind=str(x.get('kind') or 'other')
    fn=os.path.basename(str(x.get('filename','') or ''))
    if kind=='image' and fn:
        prev="<img src='/uploads/%s' style='width:100%%;max-height:260px;object-fit:contain;border-radius:14px'>" % _mrt_parse.quote(fn)
    elif kind=='video' and fn:
        prev="<video src='/uploads/%s' controls playsinline style='width:100%%;max-height:280px;border-radius:14px'></video>" % _mrt_parse.quote(fn)
    else:
        prev="<div class='mutedx'>Fără previzualizare</div>"
    return ("<article class='cardx'>%s<p>%s</p>"
            "<form method='post' action='/generated/delete'>"
            "<input type='hidden' name='rid' value='%s'>"
            "<input type='hidden' name='return_to' value='/library'>"
            "<button class='btnx secondaryx' type='submit'>🗑 Șterge</button>"
            "</form></article>") % (prev,_mrt_html_escape(x.get('prompt','')),_mrt_html_escape(rid))

def _mrt_library_v5():
    rows=[x for x in _mrt_records() if isinstance(x,dict) and x.get('status')=='ready']
    briefs=_mrt_json_load(_MRT_BRIEFS_V5,[])
    if not isinstance(briefs,list): briefs=[]

    imgs=''.join(_mrt_lib_card_v5(x) for x in reversed(rows) if x.get('kind')=='image')
    vids=''.join(_mrt_lib_card_v5(x) for x in reversed(rows) if x.get('kind')=='video')
    oth=''.join(_mrt_lib_card_v5(x) for x in reversed(rows) if x.get('kind') not in ('image','video'))

    bc=[]
    for i,b in enumerate(briefs):
        if not isinstance(b,dict): continue
        bid=str(b.get('id') or i)
        title=_mrt_html_escape(b.get('topic') or b.get('title') or 'Brief')
        desc=_mrt_html_escape(b.get('instructions') or '')
        bc.append(("<article class='cardx'><h3>%s</h3><div style='white-space:pre-wrap'>%s</div>"
                   "<form method='post' action='/briefs/delete' style='margin-top:10px'>"
                   "<input type='hidden' name='brief_id' value='%s'>"
                   "<button class='btnx secondaryx' type='submit'>🗑 Șterge</button>"
                   "</form></article>") % (title,desc,_mrt_html_escape(bid)))

    def sec(t,c,h):
        return "<section class='panelx' data-lcat='%s'><h2>%s</h2><div class='gridx'>%s</div></section>" % (c,t,h or "<p class='mutedx'>Niciun element.</p>")

    top=("<section class='panelx'><h1>Bibliotecă</h1>"
         "<p class='mutedx'>Conținutul creat este organizat automat pe categorii.</p>"
         "<div class='rowx' style='gap:8px;flex-wrap:wrap'>"
         "<button class='btnx secondaryx lfv5' data-f='all' type='button'>Toate</button>"
         "<button class='btnx secondaryx lfv5' data-f='images' type='button'>Imagini</button>"
         "<button class='btnx secondaryx lfv5' data-f='videos' type='button'>Video</button>"
         "<button class='btnx secondaryx lfv5' data-f='briefs' type='button'>Briefuri</button>"
         "<button class='btnx secondaryx lfv5' data-f='other' type='button'>Altele</button>"
         "</div></section>")
    js="<script>(function(){const b=[...document.querySelectorAll('.lfv5')],s=[...document.querySelectorAll('[data-lcat]')];b.forEach(x=>x.onclick=()=>{const f=x.dataset.f;s.forEach(y=>y.style.display=(f==='all'||y.dataset.lcat===f)?'block':'none')})})();</script>"
    return layout('Bibliotecă',top+sec('Imagini','images',imgs)+sec('Video','videos',vids)+sec('Briefuri','briefs',''.join(bc))+sec('Altele','other',oth)+js)

if 'mrt_delete_brief_v5' not in app.view_functions:
    app.add_url_rule('/briefs/delete',endpoint='mrt_delete_brief_v5',view_func=_mrt_delete_brief_v5,methods=['POST'])
if 'library' in app.view_functions:
    app.view_functions['library']=_mrt_library_v5
print('MRT_LIBRARY_V5=loaded categories=images,video,briefs,other',flush=True)



# MRT_LIBRARY_MOVE_V6=loaded
from flask import request as _mrt_lib_req_v6, redirect as _mrt_lib_redirect_v6

def _mrt_ep_for_path_v6(path):
    try:
        for _r in app.url_map.iter_rules():
            if str(_r) == path and "GET" in _r.methods:
                return _r.endpoint
    except Exception:
        pass
    return None

_mrt_library_ep_v6 = _mrt_ep_for_path_v6("/library")
if _mrt_library_ep_v6:
    def _mrt_library_redirect_handler_v6():
        return _mrt_lib_redirect_v6("/media?library=1", code=302)
    app.view_functions[_mrt_library_ep_v6] = _mrt_library_redirect_handler_v6

@app.after_request
def _mrt_library_move_after_v6(resp):
    try:
        if _mrt_lib_req_v6.path == "/media" and resp.status_code == 200 and "text/html" in (resp.content_type or ""):
            html = resp.get_data(as_text=True)
            if "MRT_LIBRARY_MOVE_V6_UI" not in html:
                js = """<script id="MRT_LIBRARY_MOVE_V6_UI">
(function(){
  function norm(s){
    return (s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim().toLowerCase().replace(/\s+/g," ");
  }
  function findLibraryBlock(){
    var nodes=[].slice.call(document.querySelectorAll("h1,h2,h3,h4,h5,h6,legend,strong,b"));
    var h=nodes.find(function(e){
      if(e.closest("nav,aside")) return false;
      return norm(e.textContent)==="biblioteca media";
    });
    if(!h) return null;
    var el=h;
    while(el && el.parentElement && el.parentElement.tagName!=="MAIN" && el.parentElement.tagName!=="BODY"){
      var p=el.parentElement;
      var cls=(p.className||"").toString().toLowerCase();
      if(p.tagName==="SECTION" || p.tagName==="ARTICLE" || /(^|\s)(card|panel|box)(\s|$)/.test(cls)) return p;
      el=p;
    }
    return h.parentElement;
  }
  function apply(){
    var lib=findLibraryBlock();
    if(!lib) return;
    var mode=(new URLSearchParams(location.search)).get("library")==="1";
    if(!mode){
      lib.style.display="none";
      return;
    }
    lib.style.display="";
    var main=lib.closest("main") || document.querySelector("main") || document.body;
    var cur=lib;
    while(cur && cur.parentElement && cur.parentElement!==main){
      [].slice.call(cur.parentElement.children).forEach(function(sib){
        if(sib!==cur && !sib.contains(cur) && !sib.matches("script,style")) sib.style.display="none";
      });
      cur=cur.parentElement;
    }
    [].slice.call(main.children).forEach(function(ch){
      if(ch!==cur && ch!==lib && !ch.contains(lib) && !ch.matches("script,style")) ch.style.display="none";
    });
    if(!document.getElementById("MRT_LIBRARY_MOVE_V6_TITLE")){
      var title=document.createElement("h1");
      title.id="MRT_LIBRARY_MOVE_V6_TITLE";
      title.textContent="Bibliotec\u0103 media";
      title.style.marginBottom="16px";
      if(main.firstChild) main.insertBefore(title, main.firstChild); else main.appendChild(title);
    }
  }
  function run(){apply(); setTimeout(apply,250); setTimeout(apply,900);}
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",run); else run();
})();
</script>"""
                if "</body>" in html:
                    html = html.replace("</body>", js + "</body>", 1)
                else:
                    html += js
                resp.set_data(html)
                resp.headers.pop("Content-Length", None)
    except Exception as e:
        print("MRT_LIBRARY_MOVE_V6_ERROR="+repr(e), flush=True)
    return resp



# MRT_LIBRARY_UI_FIX_V8_SERVER
from flask import request as _mrt_v8_request

@app.after_request
def _mrt_library_ui_fix_v8(resp):
    try:
        if _mrt_v8_request.path == "/" and resp.status_code == 200 and "text/html" in (resp.content_type or "").lower():
            html = resp.get_data(as_text=True)
            if "MRT_LIBRARY_UI_FIX_V8_CLIENT" not in html:
                script = """<script id="MRT_LIBRARY_UI_FIX_V8_CLIENT">
(function(){
  function norm(s){
    return (s||"").normalize("NFD").replace(/[\\u0300-\\u036f]/g,"").trim().toLowerCase().replace(/\\s+/g," ");
  }
  function hideRootLibrary(){
    var root=document.querySelector("main")||document.querySelector('[role="main"]')||document.body;
    if(!root) return;
    var title=[].slice.call(root.querySelectorAll("h1,h2,h3,h4,h5,h6")).find(function(el){
      return !el.closest("nav,aside") && norm(el.textContent).indexOf("biblioteca media")!==-1;
    });
    if(!title){
      title=[].slice.call(root.querySelectorAll("section,div")).find(function(el){
        if(el.closest("nav,aside")) return false;
        var t=norm(el.textContent);
        return t==="biblioteca media" || (t.indexOf("biblioteca media")===0 && t.length<100);
      });
    }
    if(!title) return;
    var box=title.closest('section,[data-section],[class*="section"],[class*="card"],[class*="panel"],[id*="library"],[id*="media"]')||title.parentElement;
    if(!box || box===document.body || box.closest("nav,aside")) return;
    box.setAttribute("data-mrt-library-hidden-on-root","1");
    box.style.setProperty("display","none","important");
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",hideRootLibrary);
  else hideRootLibrary();
  setTimeout(hideRootLibrary,100);
  setTimeout(hideRootLibrary,500);
  new MutationObserver(hideRootLibrary).observe(document.documentElement,{childList:true,subtree:true});
})();
</script>"""
                if "</body>" in html:
                    html = html.replace("</body>", script + "</body>", 1)
                else:
                    html = html + script
                resp.set_data(html)
    except Exception as e:
        print("MRT_LIBRARY_UI_FIX_V8_RESPONSE_ERR="+repr(e), flush=True)
    return resp



# MRT_PROPOSALS_DELETE_V1=loaded
from flask import request as _mrt_pdel_req_v1, jsonify as _mrt_pdel_jsonify_v1
import re as _mrt_pdel_re_v1
import unicodedata as _mrt_pdel_ud_v1

def _mrt_pdel_norm_v1(v):
    v = "" if v is None else str(v)
    v = _mrt_pdel_ud_v1.normalize("NFKD", v)
    v = "".join(ch for ch in v if not _mrt_pdel_ud_v1.combining(ch))
    v = v.lower()
    v = _mrt_pdel_re_v1.sub(r"\s+", " ", v).strip()
    return v

def _mrt_pdel_match_v1(card, row):
    if not isinstance(row, dict):
        return (0, 0, [])
    keys = ("topic","title","instructions","brief","brief_text","text","description","content")
    matched=[]
    score=0
    longest=0
    for k in keys:
        val=row.get(k)
        if not isinstance(val, str):
            continue
        nv=_mrt_pdel_norm_v1(val)
        if len(nv) < 8:
            continue
        if nv in card:
            matched.append(k)
            longest=max(longest,len(nv))
            score += min(len(nv), 600)
    return (score, longest, matched)

def _mrt_delete_brief_from_card_v1():
    data=_mrt_pdel_req_v1.get_json(silent=True)
    if not isinstance(data,dict):
        data=_mrt_pdel_req_v1.form
    card=_mrt_pdel_norm_v1(data.get("card_text","") if data else "")
    if len(card) < 12:
        return _mrt_pdel_jsonify_v1(ok=False,error="Textul brief-ului este prea scurt."),400
    rows=_mrt_json_load(_MRT_BRIEFS_V5,[])
    if not isinstance(rows,list):
        rows=[]
    candidates=[]
    for i,row in enumerate(rows):
        score,longest,matched=_mrt_pdel_match_v1(card,row)
        if score>0 and longest>=8:
            candidates.append((score,longest,len(matched),i,row))
    if not candidates:
        return _mrt_pdel_jsonify_v1(ok=False,error="Nu am putut identifica sigur brief-ul."),404
    candidates.sort(key=lambda x:(x[0],x[1],x[2]), reverse=True)
    best=candidates[0]
    if len(candidates)>1 and candidates[1][:3]==best[:3]:
        return _mrt_pdel_jsonify_v1(ok=False,error="Potrivire ambiguă; nu am șters nimic."),409
    idx=best[3]
    row=best[4] if isinstance(best[4],dict) else {}
    out=[x for j,x in enumerate(rows) if j!=idx]
    _mrt_json_save(_MRT_BRIEFS_V5,out)
    return _mrt_pdel_jsonify_v1(ok=True,deleted=True,brief_id=str(row.get("id","")),index=idx)

if "mrt_delete_brief_from_card_v1" not in app.view_functions:
    app.add_url_rule("/briefs/delete-from-card",endpoint="mrt_delete_brief_from_card_v1",view_func=_mrt_delete_brief_from_card_v1,methods=["POST"])
print("MRT_PROPOSALS_DELETE_V1=loaded",flush=True)



# MRT_TRANSCRIBE_V12=loaded
import json, os, logging
from flask import request, jsonify

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

@app.route("/api/transcribe", methods=["POST"])
def transcribe():
    """V12: Dictation with accumulated MediaRecorder chunks."""
    try:
        # Extract audio Blob metadata from multipart
        audio_file = request.files.get("audio")
        if not audio_file:
            return jsonify({"error": "missing audio file"}), 400
        
        audio_bytes = audio_file.read()
        audio_size = len(audio_bytes)
        mime_type = audio_file.content_type or "audio/webm"
        
        # Safe logs: bytes, mime, model, nonempty check only
        logger.info(f"transcribe: bytes={audio_size}, mime={mime_type}, nonempty={audio_size > 100}")
        
        # Reject implausibly small Blob
        if audio_size < 100:
            err_msg = "nu s-a înregistrat audio utilizabil"
            logger.warning(f"transcribe: rejected small audio ({audio_size} bytes): {err_msg}")
            return jsonify({"error": err_msg}), 400
        
        # Language: Romanian only
        lang = "ro"
        model = os.getenv("AI_MODEL", "gpt-4o-audio-preview")
        
        # Call OpenAI with accumulated audio
        openai_key = os.getenv("OPENAI_API_KEY", "")
        if not openai_key:
            logger.error("transcribe: missing OPENAI_API_KEY")
            return jsonify({"error": "API configuration error"}), 500
        
        try:
            from openai import OpenAI
            client = OpenAI(api_key=openai_key)
            
            logger.info(f"transcribe: calling model={model}, lang={lang}")
            
            # Transcribe with language=ro, no prompts/fallback
            response = client.audio.transcriptions.create(
                model="whisper-1",
                file=(audio_file.filename or "audio.webm", audio_bytes, mime_type),
                language=lang
            )
            
            text = response.text.strip() if response.text else ""
            logger.info(f"transcribe: success, text_len={len(text)}")
            
            return jsonify({
                "text": text,
                "language": lang,
                "model": model
            }), 200
        
        except Exception as api_err:
            # Model fallback: retry same captured audio only
            logger.warning(f"transcribe: API error (model={model}): {str(api_err)}")
            logger.info(f"transcribe: retry with same audio, bytes={audio_size}")
            
            try:
                response = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=(audio_file.filename or "audio.webm", audio_bytes, mime_type),
                    language=lang
                )
                text = response.text.strip() if response.text else ""
                logger.info(f"transcribe: retry success, text_len={len(text)}")
                return jsonify({
                    "text": text,
                    "language": lang,
                    "model": model,
                    "retry": True
                }), 200
            except Exception as retry_err:
                logger.error(f"transcribe: retry failed: {str(retry_err)}")
                return jsonify({"error": "transcription failed"}), 500
    
    except Exception as e:
        logger.error(f"transcribe: unhandled error: {str(e)}")
        return jsonify({"error": "internal server error"}), 500

# Android client (HTML/JS) patch: MediaRecorder accumulation
mrt_dictation_js = """
(function() {
  window.MRTDictationV12 = {
    recorder: null,
    chunks: [],
    isRecording: false,
    
    startDictation: function() {
      if (this.isRecording) return;
      this.chunks = [];
      this.isRecording = true;
      
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
          const options = {};
          const mimeTypes = ["audio/webm", "audio/mp4", "audio/mpeg"];
          for (const mime of mimeTypes) {
            if (MediaRecorder.isTypeSupported(mime)) {
              options.mimeType = mime;
              break;
            }
          }
          
          this.recorder = new MediaRecorder(stream, options);
          const self = this;
          
          this.recorder.ondataavailable = function(e) {
            if (e.data.size > 0) {
              self.chunks.push(e.data);
            }
          };
          
          this.recorder.onstop = function() {
            self.isRecording = false;
            const blob = new Blob(self.chunks, { type: self.recorder.mimeType });
            self.uploadAudio(blob);
          };
          
          this.recorder.start(250);
        })
        .catch(err => {
          console.error("Dictation error:", err);
          this.isRecording = false;
        });
    },
    
    stopDictation: function() {
      if (this.recorder && this.isRecording) {
        this.recorder.stop();
      }
    },
    
    uploadAudio: function(blob) {
      const formData = new FormData();
      formData.append("audio", blob, "audio." + this.getExtension());
      
      fetch("/api/transcribe", {
        method: "POST",
        body: formData
      })
      .then(r => r.json())
      .then(data => {
        if (data.error) {
          alert(data.error);
        } else {
          window.MRTDictationCallback?.(data.text);
        }
      })
      .catch(err => console.error("Upload failed:", err));
    },
    
    getExtension: function() {
      const mime = this.recorder?.mimeType || "audio/webm";
      if (mime.includes("webm")) return "webm";
      if (mime.includes("mp4")) return "m4a";
      if (mime.includes("mpeg")) return "mp3";
      return "webm";
    }
  };
})();
"""

# Inject into app
if "__name__" in globals() and __name__ == "__main__":
    print("MRT_TRANSCRIBE_V12: Flask routes + JS client ready")
