from flask import Blueprint, request, jsonify
from app.services.transcription import transcribe_audio
bp=Blueprint("transcribe",__name__)
@bp.post("/api/transcribe")
def transcribe():
    f=request.files.get("audio")
    if not f: return jsonify(error="missing audio file"),400
    b=f.read()
    if len(b)<100: return jsonify(error="nu s-a înregistrat audio utilizabil"),400
    try:
        text=transcribe_audio(f.filename,b,f.content_type or "audio/webm")
        return jsonify(text=text,language="ro")
    except Exception as e: return jsonify(error=str(e)),500
