from app import create_app
from app.services.content import save_proposals

def make_app(tmp_path):
    return create_app({"TESTING":True,"DATA_DIR":str(tmp_path / "data"),"MEDIA_DIR":str(tmp_path / "media")})

def test_create_brief(tmp_path):
    c=make_app(tmp_path).test_client()
    r=c.post("/api/content/briefs",json={"topic":"Implant dentar","platform":"Instagram","format":"Reel","tone":"Profesional","instructions":"Explică simplu"})
    assert r.status_code==201
    assert r.get_json()["topic"]=="Implant dentar"
    assert len(c.get("/api/content/briefs").get_json())==1

def test_reject_empty_topic(tmp_path):
    c=make_app(tmp_path).test_client()
    r=c.post("/api/content/briefs",json={"topic":"   "})
    assert r.status_code==400

def test_save_missing_proposal_does_not_create_one(tmp_path):
    c=make_app(tmp_path).test_client()
    brief=c.post("/api/content/briefs",json={"topic":"Igienizare"}).get_json()
    r=c.put(f'/api/content/proposals/{brief["id"]}',json={"content":"text"})
    assert r.status_code==404
    assert c.get("/api/content/proposals").get_json()=={}

def test_finalize_moves_content_to_library(tmp_path):
    app=make_app(tmp_path); c=app.test_client()
    brief=c.post("/api/content/briefs",json={"topic":"Implant dentar","platform":"Instagram","format":"Reel"}).get_json()
    with app.app_context():
        save_proposals({str(brief["id"]):{"content":"Text aprobat","status":"draft"}})
    r=c.post(f'/api/content/proposals/{brief["id"]}/finalize')
    assert r.status_code==200
    body=r.get_json()
    assert body["proposal"]["status"]=="final"
    lib=c.get("/api/content/library").get_json()
    assert len(lib)==1 and lib[0]["content"]=="Text aprobat"

def test_complete_content_flow_without_external_ai(tmp_path, monkeypatch):
    app=make_app(tmp_path); c=app.test_client()
    brief=c.post("/api/content/briefs",json={"topic":"Implant dentar","platform":"Instagram","format":"Reel","tone":"Profesional"}).get_json()
    monkeypatch.setattr("app.services.content.ai_text", lambda prompt: "Text AI sigur pentru test")
    generated=c.post(f'/api/content/proposals/{brief["id"]}/generate')
    assert generated.status_code==200
    assert generated.get_json()["status"]=="draft"
    saved=c.put(f'/api/content/proposals/{brief["id"]}',json={"content":"Text editat și aprobat"})
    assert saved.status_code==200
    finalized=c.post(f'/api/content/proposals/{brief["id"]}/finalize')
    assert finalized.status_code==200
    assert finalized.get_json()["library_item"]["content"]=="Text editat și aprobat"
    assert c.get("/api/content/library").get_json()[0]["status"]=="approved"
