
import os, json, base64, urllib.request, urllib.error, secrets, time
from datetime import datetime
from flask import request, redirect

_MRT_MEDIA_PATCH_V3_LOADED = True
_MRT_BASE = globals().get("BASE", "/tmp/mrt_dental_ai")
_MRT_MEDIA = globals().get("MEDIA", os.path.join(_MRT_BASE, "media"))
_MRT_GEN_FILE = os.path.join(_MRT_BASE, "generated_media.json")
_MRT_NOTES_FILE = os.path.join(_MRT_BASE, "media_notes.json")
os.makedirs(_MRT_MEDIA, exist_ok=True)

def _mrt_json_load(path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return fallback

def _mrt_json_save(path, value):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def _mrt_records():
    x = _mrt_json_load(_MRT_GEN_FILE, [])
    return x if isinstance(x, list) else []

def _mrt_save_records(rows):
    _mrt_json_save(_MRT_GEN_FILE, rows)

def _mrt_find(rid):
    for x in _mrt_records():
        if str(x.get("id","")) == str(rid):
            return x
    return None

def _mrt_upsert(rec):
    rows = _mrt_records()
    found = False
    for i,x in enumerate(rows):
        if str(x.get("id","")) == str(rec.get("id","")):
            rows[i] = rec
            found = True
            break
    if not found:
        rows.append(rec)
    _mrt_save_records(rows)

def _mrt_html_escape(v):
    try:
        return esc(v)
    except Exception:
        import html
        return html.escape(str(v or ""), quote=True)

def _mrt_openai_image(prompt):
    key = os.getenv("OPENAI_API_KEY","").strip()
    if not key:
        raise RuntimeError("Cheia OpenAI API nu este configurată.")
    payload = json.dumps({
        "model": "gpt-image-2",
        "prompt": prompt,
        "size": "1024x1024"
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/images/generations",
        data=payload,
        method="POST",
        headers={
            "Authorization": "Bearer " + key,
            "Content-Type": "application/json"
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            data = json.loads(resp.read().decode("utf-8","replace"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8","replace")
        try:
            j = json.loads(detail)
            msg = ((j.get("error") or {}).get("message") or detail)
        except Exception:
            msg = detail
        raise RuntimeError("OpenAI: " + str(msg)[:900])
    arr = data.get("data") if isinstance(data, dict) else None
    if not isinstance(arr, list) or not arr:
        raise RuntimeError("OpenAI nu a returnat o imagine.")
    item = arr[0] if isinstance(arr[0], dict) else {}
    raw = None
    if item.get("b64_json"):
        raw = base64.b64decode(item["b64_json"])
    elif item.get("url"):
        with urllib.request.urlopen(item["url"], timeout=120) as imgresp:
            raw = imgresp.read()
    if not raw:
        raise RuntimeError("Imaginea a fost generată, dar fișierul nu a putut fi citit.")
    filename = datetime.now().strftime("generated_%Y%m%d_%H%M%S_") + secrets.token_hex(4) + ".png"
    with open(os.path.join(_MRT_MEDIA, filename), "wb") as f:
        f.write(raw)
    return filename

def _mrt_fal_submit(prompt, aspect_ratio, duration, resolution, generate_audio):
    key = os.getenv("FAL_KEY","").strip()
    if not key:
        raise RuntimeError("Pentru generare video mai trebuie configurată cheia FAL_KEY.")
    endpoint = "bytedance/seedance-2.5/us/text-to-video"
    payload = json.dumps({
        "prompt": prompt,
        "aspect_ratio": aspect_ratio,
        "duration": duration,
        "resolution": resolution,
        "generate_audio": bool(generate_audio)
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://queue.fal.run/" + endpoint,
        data=payload,
        method="POST",
        headers={
            "Authorization": "Key " + key,
            "Content-Type": "application/json"
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8","replace"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8","replace")
        raise RuntimeError("fal.ai: " + detail[:900])
    if not data.get("request_id"):
        raise RuntimeError("fal.ai nu a returnat un request_id.")
    return data

def _mrt_fal_refresh(rec):
    if rec.get("kind") != "video" or rec.get("status") not in ("pending","processing"):
        return rec
    key = os.getenv("FAL_KEY","").strip()
    if not key:
        return rec
    status_url = rec.get("status_url")
    response_url = rec.get("response_url")
    if not status_url:
        return rec
    headers = {"Authorization": "Key " + key}
    try:
        req = urllib.request.Request(status_url, headers=headers)
        with urllib.request.urlopen(req, timeout=20) as resp:
            st = json.loads(resp.read().decode("utf-8","replace"))
        q = str(st.get("status","")).upper()
        if q == "COMPLETED":
            if response_url:
                req2 = urllib.request.Request(response_url, headers=headers)
                with urllib.request.urlopen(req2, timeout=30) as resp2:
                    result = json.loads(resp2.read().decode("utf-8","replace"))
                video = result.get("video") if isinstance(result, dict) else None
                url = video.get("url") if isinstance(video, dict) else None
                if url:
                    filename = datetime.now().strftime("generated_%Y%m%d_%H%M%S_") + secrets.token_hex(4) + ".mp4"
                    with urllib.request.urlopen(url, timeout=180) as vresp:
                        raw = vresp.read()
                    with open(os.path.join(_MRT_MEDIA, filename), "wb") as f:
                        f.write(raw)
                    rec["filename"] = filename
                    rec["status"] = "ready"
                    rec["updated_at"] = datetime.now().isoformat()
        elif q in ("IN_QUEUE","IN_PROGRESS"):
            rec["status"] = "processing" if q == "IN_PROGRESS" else "pending"
        return rec
    except Exception as e:
        rec["last_error"] = str(e)[:500]
        return rec

def _mrt_save_to_library(rec):
    if not rec or not rec.get("filename"):
        return False
    notes = _mrt_json_load(_MRT_NOTES_FILE, [])
    if not isinstance(notes, list):
        notes = []
    if any(str(x.get("generated_id","")) == str(rec.get("id","")) for x in notes if isinstance(x,dict)):
        return True
    notes.append({
        "generated_id": rec.get("id"),
        "stored_name": rec.get("filename"),
        "original_name": rec.get("filename"),
        "content_type": "image/png" if rec.get("kind") == "image" else "video/mp4",
        "note": rec.get("prompt",""),
        "created_at": datetime.now().strftime("%d.%m.%Y %H:%M")
    })
    _mrt_json_save(_MRT_NOTES_FILE, notes)
    rec["saved"] = True
    _mrt_upsert(rec)
    return True

def _mrt_generate_view():
    error = ""
    rid = request.args.get("rid","").strip()
    rec = _mrt_find(rid) if rid else None

    if request.method == "POST":
        kind = request.form.get("kind","image").strip()
        prompt = request.form.get("prompt","").strip()
        if not prompt:
            error = "Scrie sau dictează descrierea înainte de generare."
        elif kind == "image":
            try:
                filename = _mrt_openai_image(prompt)
                rec = {
                    "id": secrets.token_hex(8),
                    "kind": "image",
                    "prompt": prompt,
                    "filename": filename,
                    "status": "ready",
                    "saved": False,
                    "created_at": datetime.now().isoformat()
                }
                _mrt_upsert(rec)
                return redirect("/generate?rid=" + rec["id"])
            except Exception as e:
                error = str(e)
        elif kind == "video":
            try:
                aspect_ratio = request.form.get("aspect_ratio","9:16")
                duration = request.form.get("duration","5")
                resolution = request.form.get("resolution","720p")
                generate_audio = request.form.get("generate_audio") == "1"
                data = _mrt_fal_submit(prompt, aspect_ratio, duration, resolution, generate_audio)
                rec = {
                    "id": secrets.token_hex(8),
                    "kind": "video",
                    "prompt": prompt,
                    "status": "pending",
                    "saved": False,
                    "request_id": data.get("request_id"),
                    "status_url": data.get("status_url"),
                    "response_url": data.get("response_url"),
                    "created_at": datetime.now().isoformat()
                }
                _mrt_upsert(rec)
                return redirect("/generate?rid=" + rec["id"])
            except Exception as e:
                error = str(e)

    if rec and rec.get("kind") == "video" and rec.get("status") in ("pending","processing"):
        rec = _mrt_fal_refresh(rec)
        _mrt_upsert(rec)

    selected_kind = (rec or {}).get("kind","image")
    prompt_value = (rec or {}).get("prompt","")
    fal_ready = bool(os.getenv("FAL_KEY","").strip())

    result_html = ""
    if rec:
        if rec.get("status") == "ready" and rec.get("filename"):
            src = "/uploads/" + urllib.parse.quote(rec.get("filename",""))
            if rec.get("kind") == "image":
                media = f'<img src="{src}" alt="Imagine generată" style="width:100%;max-width:720px;border-radius:16px;border:1px solid #e5e7eb;display:block;margin:0 auto">'
            else:
                media = f'<video src="{src}" controls playsinline style="width:100%;max-width:720px;border-radius:16px;border:1px solid #e5e7eb;display:block;margin:0 auto"></video>'
            saved = bool(rec.get("saved"))
            save_btn = '<p style="color:#047857;font-weight:700">✓ Salvat în bibliotecă</p>' if saved else (
                '<form method="post" action="/generated/save"><input type="hidden" name="rid" value="'+_mrt_html_escape(rec.get("id"))+'">'
                '<button class="btnx primaryx" type="submit">✓ Salvează în bibliotecă</button></form>'
            )
            result_html = '<section class="panelx"><h2>Rezultat generat</h2>'+media+'<div style="margin-top:16px">'+save_btn+'</div></section>'
        elif rec.get("kind") == "video":
            status_text = "În coadă..." if rec.get("status") == "pending" else "Se generează..."
            result_html = (
                '<section class="panelx"><h2>Video în curs</h2><p>'+status_text+'</p>'
                '<a class="btnx secondaryx" href="/generate?rid='+_mrt_html_escape(rec.get("id"))+'">Verifică statusul</a></section>'
            )

    err_html = ('<div class="cardx" style="border-color:#fecaca;background:#fff7f7;color:#991b1b"><strong>'+_mrt_html_escape(error)+'</strong></div>') if error else ""
    fal_note = "" if fal_ready else '<p class="mutedx" id="video-note">Generarea video este pregătită în interfață, dar pentru a porni efectiv mai trebuie configurată cheia FAL_KEY.</p>'

    content = f'''
<section class="panelx">
  <h2>Generează imagine sau video</h2>
  <p class="mutedx">Descrii ce vrei, prin voce sau text, iar aplicația generează media propriu-zisă — nu un răspuns textual.</p>
  {err_html}
  <form method="post" id="mrt-media-form">
    <label>Ce vrei să generezi?</label>
    <div class="rowx" style="margin-bottom:12px">
      <label style="display:inline-flex;gap:7px;align-items:center;margin:0"><input style="width:auto" type="radio" name="kind" value="image" {"checked" if selected_kind=="image" else ""}> Imagine</label>
      <label style="display:inline-flex;gap:7px;align-items:center;margin:0"><input style="width:auto" type="radio" name="kind" value="video" {"checked" if selected_kind=="video" else ""}> Video</label>
    </div>

    <label>Descriere</label>
    <textarea id="mrt-prompt" data-mrt-voice="1" name="prompt" rows="8" placeholder="Ex.: Generează un incisiv central superior cu anatomie realistă, parodonțiu și os alveolar...">{_mrt_html_escape(prompt_value)}</textarea>
    <div class="rowx" style="margin:8px 0 14px">
      <button class="btnx secondaryx" id="mrt-dictate" type="button">🎙 Dictează</button>
      <span id="mrt-dictate-status" class="mutedx">română</span>
    </div>

    <div id="mrt-video-options" style="display:none">
      <div class="formgrid">
        <label>Format
          <select name="aspect_ratio">
            <option value="9:16">9:16 vertical</option>
            <option value="1:1">1:1 pătrat</option>
            <option value="16:9">16:9 landscape</option>
          </select>
        </label>
        <label>Durată
          <select name="duration">
            <option value="5">5 secunde</option>
            <option value="8">8 secunde</option>
            <option value="10">10 secunde</option>
          </select>
        </label>
        <label>Rezoluție
          <select name="resolution">
            <option value="720p">720p</option>
            <option value="1080p">1080p</option>
            <option value="480p">480p</option>
          </select>
        </label>
      </div>
      <label style="display:flex;gap:8px;align-items:center"><input style="width:auto" type="checkbox" name="generate_audio" value="1"> Generează și sunet</label>
      {fal_note}
    </div>

    <button class="btnx primaryx" type="submit" style="margin-top:10px">✨ Generează</button>
  </form>
</section>
{result_html}

<script>
(function(){{
  const form=document.getElementById('mrt-media-form');
  const videoBox=document.getElementById('mrt-video-options');
  function syncKind(){{
    const k=(form.querySelector('input[name="kind"]:checked')||{{value:'image'}}).value;
    videoBox.style.display=k==='video'?'block':'none';
  }}
  form.querySelectorAll('input[name="kind"]').forEach(x=>x.addEventListener('change',syncKind));
  syncKind();

  const ta=document.getElementById('mrt-prompt');
  const btn=document.getElementById('mrt-dictate');
  const status=document.getElementById('mrt-dictate-status');
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){{
    btn.disabled=true;
    status.textContent='dictare indisponibilă în acest browser';
    return;
  }}
  let rec=null, active=false, base='';
  btn.addEventListener('click',function(){{
    if(active){{ try{{rec.stop()}}catch(e){{}} return; }}
    rec=new SR();
    rec.lang='ro-RO';
    rec.continuous=true;
    rec.interimResults=true;
    base=(ta.value||'').trim();
    if(base) base += ' ';
    rec.onstart=()=>{{active=true;btn.textContent='■ Oprește';status.textContent='ascult…';}};
    rec.onresult=(ev)=>{{
      let finals='', interim='';
      for(let i=ev.resultIndex;i<ev.results.length;i++){{
        const t=(ev.results[i][0].transcript||'').trim();
        if(!t) continue;
        if(ev.results[i].isFinal) finals += (finals?' ':'') + t;
        else interim += (interim?' ':'') + t;
      }}
      ta.value=(base + finals + (interim ? (finals?' ':'')+interim : '')).trim();
      ta.dispatchEvent(new Event('input',{{bubbles:true}}));
    }};
    rec.onerror=(ev)=>{{status.textContent=ev.error==='not-allowed'?'permite accesul la microfon':'eroare microfon';}};
    rec.onend=()=>{{active=false;btn.textContent='🎙 Dictează';if(status.textContent==='ascult…') status.textContent='română';}};
    try{{rec.start()}}catch(e){{status.textContent='încearcă din nou';}}
  }});
}})();

;(function(){{
  function installMrtSpeechV2(){{
    const oldBtn=document.getElementById('mrt-dictate');
    const ta=document.getElementById('mrt-prompt');
    const status=document.getElementById('mrt-dictate-status');
    if(!oldBtn||!ta||!status) return;
    if(oldBtn.dataset && oldBtn.dataset.mrtSpeechV2==='1') return;

    // Replace the node to remove every older/global click listener.
    const btn=oldBtn.cloneNode(true);
    btn.removeAttribute('data-mrt-voice');
    btn.dataset.mrtSpeechV2='1';
    oldBtn.replaceWith(btn);

    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){{
      btn.disabled=true;
      status.textContent='dictare indisponibilă în acest browser';
      return;
    }}

    let rec=null, active=false, prefix='', committed='';

    const clean=(s)=>(s||'').trim().replace(/\s+/g,' ');

    function mergeOverlap(a,b){{
      a=clean(a); b=clean(b);
      if(!a) return b;
      if(!b) return a;
      const al=a.toLocaleLowerCase('ro-RO');
      const bl=b.toLocaleLowerCase('ro-RO');
      if(al===bl) return a;
      if(bl.startsWith(al+' ')) return b;
      if(al.endsWith(' '+bl) || al===bl) return a;

      const aw=a.split(' '), bw=b.split(' ');
      const an=aw.map(x=>x.toLocaleLowerCase('ro-RO'));
      const bn=bw.map(x=>x.toLocaleLowerCase('ro-RO'));
      const max=Math.min(an.length,bn.length);
      for(let k=max;k>0;k--){{
        let ok=true;
        for(let j=0;j<k;j++){{
          if(an[an.length-k+j]!==bn[j]){{ok=false;break;}}
        }}
        if(ok) return aw.concat(bw.slice(k)).join(' ');
      }}
      return a+' '+b;
    }}

    function render(interim){{
      const spoken=mergeOverlap(committed,interim||'');
      ta.value=clean((prefix?prefix+' ':'')+spoken);
      ta.dispatchEvent(new Event('input',{{bubbles:true}}));
    }}

    btn.addEventListener('click',function(ev){{
      ev.preventDefault();
      ev.stopImmediatePropagation();

      if(active){{
        try{{rec.stop();}}catch(e){{}}
        return;
      }}

      prefix=clean(ta.value);
      committed='';
      rec=new SR();
      rec.lang='ro-RO';
      rec.continuous=true;
      rec.interimResults=true;

      rec.onstart=()=>{{
        active=true;
        btn.textContent='■ Oprește';
        status.textContent='ascult…';
      }};

      rec.onresult=(ev)=>{{
        let interim='';
        for(let i=ev.resultIndex;i<ev.results.length;i++){{
          const alt=ev.results[i] && ev.results[i][0];
          const t=clean(alt && alt.transcript);
          if(!t) continue;
          if(ev.results[i].isFinal){{
            committed=mergeOverlap(committed,t);
          }}else{{
            interim=t;
          }}
        }}
        render(interim);
      }};

      rec.onerror=(ev)=>{{
        status.textContent=ev.error==='not-allowed'?'permite accesul la microfon':'eroare microfon';
      }};

      rec.onend=()=>{{
        active=false;
        btn.textContent='🎙 Dictează';
        if(status.textContent==='ascult…') status.textContent='română';
        rec=null;
      }};

      try{{rec.start();}}catch(e){{status.textContent='încearcă din nou';}}
    }},true);
  }}

  const boot=()=>setTimeout(installMrtSpeechV2,120);
  if(document.readyState==='loading'){{
    document.addEventListener('DOMContentLoaded',boot,{{once:true}});
  }}else{{
    boot();
  }}
}})();
</script>
'''
    return layout("Generează conținut", content)

def _mrt_generated_save():
    rid = request.form.get("rid","").strip()
    rec = _mrt_find(rid)
    if rec:
        _mrt_save_to_library(rec)
    return redirect("/generate?rid=" + urllib.parse.quote(rid))

app.view_functions["generate"] = _mrt_generate_view
if "mrt_generated_save" not in app.view_functions:
    app.add_url_rule("/generated/save", endpoint="mrt_generated_save", view_func=_mrt_generated_save, methods=["POST"])

print("MRT_MEDIA_PATCH_V3=loaded", flush=True)
